
#include <stdio.h>

void main()
  {
    int day, year;
    char weekday[10], month[12];

    scanf( "%s %s %d %d", weekday, month, &day, &year );
  }

