#include <stdio.h>

void main()
  {
    printf( "The number of open files is %d\n",
            flushall() );
  }
