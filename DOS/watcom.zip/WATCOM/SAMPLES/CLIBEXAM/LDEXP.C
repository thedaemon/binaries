#include <stdio.h>
#include <math.h>

void main()
  {
    double value;

    value = ldexp( 4.7072345, 5 );
    printf( "%f\n", value );
  }
