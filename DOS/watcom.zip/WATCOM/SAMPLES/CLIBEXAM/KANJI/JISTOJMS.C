#include <stdio.h>
#include <jstring.h>

void main()
  {
    unsigned short c;

    c = jistojms( 0x2152 );
    printf( "%x\n", c );
  }
