#include <stdio.h>
#include <jstring.h>

void main()
  {
    printf( "%s\n",
            jstrstr( "This is an example", "is" )
          );
  }
