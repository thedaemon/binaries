#include <stdlib.h>

void main()
  {
    int x;

    x = atoi( "-289" );
  }
