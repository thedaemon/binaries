#include <stdio.h>
#include <stdlib.h>

void main()
  {
    printf( "%d %d %d\n", abs( -5 ), abs( 0 ), abs( 5 ) );
  }
